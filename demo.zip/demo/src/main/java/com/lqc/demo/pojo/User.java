package com.lqc.demo.pojo;

import jakarta.persistence.*;

@Table(name = "Table_User2")
@Entity
public class User   {
    @Id @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "user_id")
    private Integer UserId;
    @Column(name = "user_name")
    private String UserName;
    @Column(name = "user_password")
    private String Password;
    @Column(name = "user_email")
    private String email;

    public Integer getUserId() {
        return UserId;
    }

    public void setUserId(Integer userId) {
        UserId = userId;
    }

    public String getUserName() {
        return UserName;
    }

    public void setUserName(String userName) {
        UserName = userName;
    }

    public String getPassword() {
        return Password;
    }

    public void setPassword(String password) {
        Password = password;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    @Override
    public String toString() {
        return "User{" +
                "UserId=" + UserId +
                ", UserName='" + UserName + '\'' +
                ", Password='" + Password + '\'' +
                ", eamil='" + email + '\'' +
                '}';
    }
}
