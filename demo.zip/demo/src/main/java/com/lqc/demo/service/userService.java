package com.lqc.demo.service;

import com.lqc.demo.pojo.User;
import com.lqc.demo.pojo.dto.UserDto;
import com.lqc.demo.repository.UserRepository;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class userService implements IUserService {
    @Autowired
    UserRepository userRepository;
        @Override
    public User add(UserDto user) {
        //调用
            User userpojo = new User();
            BeanUtils.copyProperties(user,userpojo);
        userRepository.save(userpojo);
            return userpojo;
        }

    @Override
    public User getUser(Integer userId) {
        return userRepository.findById(userId).orElseThrow(() -> {
            throw new RuntimeException("用户不存在");
        });
    }

    @Override
    public User edit(UserDto user) {
        User userpojo = new User();
        BeanUtils.copyProperties(user,userpojo);
        return userRepository.save(userpojo);
    }

    @Override
    public void delete(Integer userId) {
         userRepository.deleteById(userId);
    }


}
