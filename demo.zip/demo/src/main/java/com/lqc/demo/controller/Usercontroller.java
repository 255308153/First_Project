package com.lqc.demo.controller;

import com.lqc.demo.pojo.ResponseMessage;
import com.lqc.demo.pojo.User;
import com.lqc.demo.pojo.dto.UserDto;
import com.lqc.demo.service.IUserService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/user")

public class Usercontroller {
    @Autowired
    IUserService userService;
    // 增加
    @PostMapping
    public ResponseMessage add(@Validated @RequestBody UserDto user){
      User userNew = userService.add(user);
      return  ResponseMessage.success(userNew);
    }
    //查询
    @GetMapping("/{userId}")
    public ResponseMessage get(@PathVariable Integer userId){
         User userNew = userService.getUser(userId);
        return  ResponseMessage.success(userNew);
    }
    //修改
    @PutMapping
    public ResponseMessage edit(@Validated @RequestBody UserDto user){
        User userNew = userService.edit(user);
        return  ResponseMessage.success(userNew);
    }
    //删除
    @DeleteMapping("/{userId}")
    public ResponseMessage delet(@PathVariable Integer userId){
        userService.delete(userId);
        return  ResponseMessage.success();
    }
}
